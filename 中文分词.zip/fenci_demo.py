# encoding=utf-8
import jieba

jieba.enable_paddle()
strs=["他说：在座的同志中，年轻的居多，我们毕竟已年逾花甲，希望还在你们身上"]
for str in strs:
    seg_list = jieba.cut(str,use_paddle=True)
    print("Paddle Mode: " + '/'.join(list(seg_list)))




