#encoding=utf-8
import hanlp

sents=CorpuLoader.convert2SentenceList(corpus_path)

def train_bigram(corpus_path, model_path):
	for sent in sents:
		for word in sent:
			word.setLabel(“n”)
	maker = NatureDictionaryMaker()
	maker.compute(sents)
	maker.saveTxtTo(model_path)


# 加载预测模型

def load_bigram(model_path):
	HanLP.Config.CoreDictionaryPath = model_path + ".txt"
	HanLP.Config.BiGramDictionaryPath = model_path + ".ngram.txt"
	CoreDictionary = SafeJClass('com.hankcs.hanlp.dictionary.CoreDictionary')
	CoreBiGramTableDictionary = SafeJClass('com.hankcs.hanlp.dictionary.CoreBiGramTableDictionary')
pred1 = CoreDictionary.getTermFrequency("单词1") 
pred2 = CoreBiGramTableDictionary.getBiFrequency("单词1","单词2")


#构建预测词网

def generate_wordnet(sent,trie):
	searcher = trie.getSearcher(JString(sent),0)
	wordnet = WordNet(sent)
	while searcher.next():
		wordnet.add(searcher.begin + 1, Vertex(sent[searcher.begin:searcher.begin + searcher.length], searcher.value, searcher.index))
	vertexes = wordnet.getVertexes()
	i= 0
	while i < len(vertexes):
		if len(vertexes[i]) == 0:
			j = i + 1
			for j in range (i + 1, len(vertexes) - 1):
				if len(vertexes[j]):
					break
			wordnet.add(i, Vertexes.newPunctuationInstance(sent[i – 1: j - 1]))
			i = j
                else:
		     i += len(vertexes[i][-1].realword)
	return wordnet

#模型测试

train_bigram(msr_train, msr_model) #训练
segment = load_bigram(msr_model) #加载
result = CWSEvaluator.evaluate(segment, msr_test, msr_output, msr_output, msr_gold, msr_dict) #预测打分

